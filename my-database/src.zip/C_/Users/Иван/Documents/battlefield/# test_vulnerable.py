# test_vulnerable.py
import os
os.system('ls')  # Уязвимость3
